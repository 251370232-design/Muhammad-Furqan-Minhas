import java.util.Scanner;

public class AgeCalculator{
	public static void main(String []args){
		Scanner input = new Scanner(System.in);
			System.out.print("Enter your birth year:");
			int birthyear = input.nextInt();


			System.out.print("Enter the current year:");
			int currentyear =input.nextInt();


			int age = currentyear-birthyear;


			System.out.println("\n________Age Calculation Result_________");
			System.out.println("birthyear      :" +birthyear);
			System.out.println("currentyear    :" +currentyear);
			System.out.println("Your age is    :" +age + " years");
			System.out.println("_________________________________________");

		
	}
}